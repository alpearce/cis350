/** Automatically generated file. DO NOT MODIFY */
package edu.cis350.mosstalkwords;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}